function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '3rem' }}>
      <h1>Hello World</h1>
    </div>
  );
}

export default App;
